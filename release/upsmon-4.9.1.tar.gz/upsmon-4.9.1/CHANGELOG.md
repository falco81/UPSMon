# Changelog

Every version is a package in `release/` (the last ten are kept), signed with
the release key whose public half is in `deploy/release-keys/`. The root of
the repository is the package unpacked.

## 4.9.1 - 2026-11-20

Bugs found and put right.

- **Files sent from the pages** (a new version in Upgrades, a database put back, a backup from
  another machine) were all refused with "that request did not come from this page" (403) since
  4.0.0: the pages send the header X-Upsmon-Restore, the guard looked for OTP's X-Otp-Restore.
  On nginx they went to `/admin/upload/` first, which upsmon's nginx answers 413 for anything
  over 64 kB - straight to the page now.
- **A session that ran out** (or was signed out elsewhere) never went back to the sign-in: the
  page asked as OTP's `/admin/` pages ask (`?api=me`, no road here) and said "The daemon is not
  answering" for good. Back to the sign-in within seconds now.
- **SELinux - Put in what is selected** (4.9.0) believed things any user of the machine may
  write into the audit log: the word "upsmon" in a program's name, a path or its arguments made
  a refusal "upsmon's", and a rule for it could be put in for any domain. Now whose a refusal
  is comes only from what the kernel wrote - the uid (upsmon.service and its tools run as
  `upsmon`, the PHP of the pages as `upsmon-www`), the object's path, the ports in upsmon's own
  nginx file (not the daemon's request). A rule of upsmon's may only allow what upsmon itself
  needs (upsmon.service starting its tools, the tools answering it, the web server reading
  upsmon's own pages and run files); never a rule on a port type; a permission the loaded policy
  does not know is not offered (it would do nothing). Programs upsmon works with (the web
  server, the services, its tools) are never "not upsmon's" - they count against enforcing as
  before. Each AVC line is answered by audit2why and counted by itself (one event holds several);
  fields are read from the end (a USER_AVC's command line cannot pose as them; USER_AVC is never
  put right from here); `node=` before the records (auditd name_format) is read; a label is put
  right by its real path and only counted as put right when restorecon ran;
  `upsmon --selinux-fix all` hands "all" to root.
- **The upgrade band** (4.8.0): "being upgraded" only while one runs - a daemon that is down
  after an upgrade ended is said down in red again (it was hidden for 10 minutes, with saves
  failing silently); who asked and why it failed only in the status of a signed-in page, never
  to a page without a real session; the sign-in page seen from elsewhere no longer loads itself
  again and again when the database will not open (and at most once in half a minute anyway);
  an upgrade is told apart by its version and start, so the same version tried again reloads
  the dashboard; no reload when a failed upgrade's record runs out; a "running" left behind by a
  restart of the machine in the middle of one is no longer believed once the daemon is up
  (its health says how long it runs).
- The passkeys test wrote `undefined-*.png` into the repository when run without a folder.

## 4.9.0 - 2026-11-17

SELinux as the SELinux kit describes it: what SELinux refuses, sorted by what puts it right, and
a button that puts right what may safely be put right. See `docs/selinux-and-trusted-roots.md`.

- **What SELinux refuses** (Settings → SELinux): every AVC, USER_AVC and SELINUX_ERR since the
  start, read with the records of its event (the program, the whole path, the port), grouped,
  put to `audit2why` and sorted - *a label* (restorecon), *a boolean* (setsebool -P, never one
  that allows far more), *a port* (semanage port -a, never another service's), *a rule of
  upsmon's* (one rule in upsmon's own local module `upsmon_local`), *not for a button* (with
  why: security-sensitive targets, executing and transitions, capabilities, unsafe classes,
  writes to generic types), *not upsmon's* (other programs - shown, never put right; they no
  longer hold enforcing back). A finding's id is the same at every look.
- **Put in what is selected (N)**: ticked by default, select all per group, a confirm that lists
  exactly what root will do. The page sends only the ids - root finds them again and works out
  every fix itself; every step in Events; works under enforcing too. What was put right is
  "Put right just now"; refused again after it, it comes back.
- **upsmon's local rules** with *Take it away* (the last one: `semodule -r upsmon_local`).
- `upsmon_server.cil`: `nnp_transition` into the domains of the tools the daemon runs under
  NoNewPrivileges (ip, ssh/sftp/scp, ssh-keygen; chronyc, hostname, ping), each `optional` -
  checked with `secilc`.
- The report: `os/` for the whole machine (every process, boolean, port type, module, local
  changes, `semanage export`, listening sockets), and the local module.
- Command line: `upsmon --selinux-look`, `--selinux-fix ID... | all`, `--selinux-rules
  [--take-away ID]`. `install.sh --uninstall` takes `upsmon_local` away too.
- In Czech too. Tests: `tests/selinux-find/` (38 + 14 checks); the 4.6.0 ones pass unchanged.

## 4.8.0 - 2026-11-17

The upgrade on the pages, as the upgrade-UI kit describes it: the pages stay with an
upgrade that restarts the daemon, nginx and PHP. See `docs/upgrade-ui.md`.

- **`/var/www/upsmon/.upgrade.json`** - how far an upgrade is, written by install.sh
  --upgrade (each step, `done`, `failed` from its EXIT trap, also when it is interrupted or
  stopped) and by the root helper (the package taken and checked, its own failures, the
  end); root's, 0644, renamed into place, never served by nginx. PHP reads it from the
  disk, with limits (30 min running, 10 min ended) and every field checked.
- While the daemon is away during an upgrade every call answers **503 "being upgraded"**
  with the progress, not "the daemon is not answering"; `?api=upgrade-state` answers
  without the daemon; the status carries it while the daemon answers.
- **Settings**: a blue band under the header - the version, from, asked by, how long, a
  bar, the step N of M, and what is away (the daemon, or nginx and PHP) for how long; the
  pill *in maintenance*; no red bar, no red toasts while it runs. When it is done the page
  loads the new version once (not over changes not saved). A failure is a red band with
  the reason and *Open Upgrades*, hidden with ×. Settings → Upgrades shows the progress
  from the disk while the daemon is away.
- **The sign-in page** shows the band (without who asked) and loads itself again once the
  daemon answers; **the dashboard** a blue band and *In maintenance*, loaded once when done.
- In Czech too. Tests: `tests/upgrade-ui/t_sim.js` (25 checks).

## 4.7.1 - 2026-11-12

The whole chain as plexmon 2.9.8 describes it, for every application of ours.

- **Upload the missing authority** - when the intermediate cannot be fetched (no CA
  Issuers address, no way out, a private CA): a dialog says which authority is missing
  and takes it as PEM or a .cer / .crt file (Read a file…). Only certificates of
  authorities, never a key; the certificate and its key stay; a root is kept to check
  with and never sent; one that is not the issuer of the chain's last link is refused.
- **A private CA**: a chain that leads to a root the system does not trust is said so
  ("it leads to …, a root the system does not trust (a private CA?)"); with its root
  uploaded it is complete - "a private root: only clients that trust it take it".
- On the card's buttons: **Complete the chain** (primary, when it is incomplete) or
  **Check the chain**, and Upload the missing authority beside it; none for a
  self-signed one. The words of each state as described; *Chain* green or red.
- **The file nginx has now** is checked too (the system's roots, nothing fetched),
  kept by the file's time - a certificate put in before this version is caught.
- The self-check after nginx reloads asks as Python does, with the root kept for a
  private CA; "checked as a client that fetches nothing: the whole chain is sent", or an
  event when refused.
- The answers say `complete`, never `ok: false` (the pages took that for an error with no
  words); openssl's words without the paths of its temporary files; what was fetched is
  kept a day, at most 256 kB each.

## 4.7.0 - 2026-11-12

The same as acme 1.0.88 found on isemon: a certificate uploaded **without its
intermediate** (the leaf alone, as many CAs mail it) was served by nginx alone. Browsers
fetch the missing link themselves and said nothing; Python, curl, openssl, Java,
monitoring and acme refused it ("unable to get local issuer certificate").

- **The chain is completed as browsers do.** When what was uploaded (or ordered, or
  pushed by acme) does not reach a root of the system's trust, the issuer is fetched from
  the certificate's Authority Information Access -> CA Issuers (DER, PEM or PKCS#7),
  up to four steps, and kept only when the chain then verifies against the system's
  roots (or the root uploaded with it - a company CA). The root itself is never sent.
  Fetched straight, never through the proxy.
- **Checked against the system's roots** - before only against a root uploaded with it.
  An upload that cannot be completed is kept with a clear warning and an event.
- **Settings -> Certificates and TLS**, on the card: *Chain* - "complete (2
  certificates up to …)" in green, or "incomplete - the intermediate … is not sent" in
  red with why, and **Complete the chain** for the certificate already in place.
- **Served**: once nginx has a certificate, upsmon connects to itself (127.0.0.1:443 with
  its name) as a client that fetches nothing and says what nginx sends and whether that
  is trusted - a failure is an event, not silence.
- Already right, and kept so: nginx gets the certificate followed by its chain, the
  intermediates in order and the root left out; ACME and acme push give the whole chain.

## 4.6.1 - 2026-11-08

- **The SELinux report: processes.txt was empty.** `ps -eZo ...` is refused by procps
  ("can not use output modifiers with user-defined output") and the filter threw the
  refusal away too. It is `ps -eo label,...` now - the domain each program runs in -
  and a command that says nothing is said to have said nothing, with its exit code.
- Looked through on a real AlmaLinux 9.8 (permissive): every label, the boolean and the
  module as upsmon needs them; the only refusals (php-fpm -> 127.0.0.1:9849,
  `name_connect`) were from the minute before `httpd_can_network_connect` was put in,
  and are not counted since - ready for enforcing.

## 4.6.0 - 2026-11-08

From otp 1.0.265 ("SELinux support and the system's trusted roots"), for one server.

- **Settings -> SELinux** (a new pane): how SELinux is here and what upsmon needs of
  it - its module, the labels of its files, the booleans - and what SELinux refused
  since the machine started, or since upsmon's needs were put in. The way to
  enforcing one step at a time: Make it ready (permissive at the next restart, every
  file labelled), Put in what upsmon needs, Switch to enforcing (refused while
  anything is missing, anything was refused or auditd does not run), Back to
  permissive. Nothing changes unless asked: a machine with SELinux disabled stays so.
  Download the report: what whoever writes the module needs - nothing is changed to
  make it.
- **upsmon's SELinux module** (`upsmon_server.cil`): `/run/upsmon` labelled
  `httpd_var_run_t` (the pages read the daemon's tokens there), and systemd may hand
  it back to the service under enforcing. install.sh puts in the tools and auditd,
  and the module only when it changed; `--uninstall` takes it out.
- A refused "Switch to enforcing" that put something in on the way no longer leaves
  what was refused before counting for good: the next "Put in what upsmon needs"
  marks it.
- **Settings -> Certificates and TLS -> Trusted roots of the system**: certificate
  authorities of your own put into the trust of the whole system (curl, dnf, LDAPS,
  SMTP, upsmon's own connections) the system's own way - update-ca-trust or
  update-ca-certificates - beside the distribution's list, which keeps coming with
  its updates. Only `upsmon-<sha256>` files are written; what others put there is
  shown and left alone. Authorities only (CA:TRUE), warnings for an expired one, weak
  signatures and keys, an intermediate without its root. Add as PEM, a chain or a
  .cer file; download, take away.
- CLI: `upsmon --selinux-check`, `--selinux STEP`, `--selinux-report [FILE]`,
  `--os-roots`, `--os-roots-add FILE`, `--os-roots-remove SHA256`.
- upsmon-web.path watches `selinux.ask` and `osroots.ask` too, and is started again by
  install.sh so that it does. docs/selinux-and-trusted-roots.md.

## 4.5.1 - 2026-11-06

- **To be done by hand: Clear for "Done lately"** (as ZIGMon 5.44.3 has it). A
  Clear button at the right of the heading empties exactly the rows the pane
  shows - a row come meanwhile stays - and never touches what is still to be
  done; it is said in the events. The table, and its Clear, is drawn only when
  it has rows. `upsmon --notices-clear-done` on the command line empties all of it.
- Nothing pending: a green strip, "Nothing is to be done by hand".
- "Done lately" keeps the last 20, shows the 10 newest; "went by itself" for
  one whose check holds. A done one cleared away (or past the 20) is not raised
  again while root's file still asks the same.
- `/api/notices` is for a full administrator only, reading too.

## 4.5.0 - 2026-11-06

- **What is to be done by hand - one way for all of it.** A step a new version
  needs on the command line, what the installer had to leave to the administrator
  (SELinux, the firewall, a package), what the daemon finds: a notice, kept until
  it is done.
  - **Settings → Upgrades**, the first card: a band each (as isemon's), red,
    amber or blue, the commands with Copy, **Done** (a full administrator, kept
    with the name) and **Look again**; below it, what was done lately. Beside
    Upgrades in the menu, how many, in the colour of the worst. Nothing new over
    the pages - the alerts at the top stay as they were.
  - **The dashboard** says only that something is to be done (warn and danger),
    with a link to Settings; `/api/status` and `/api/health` carry only how many
    and how bad.
  - **The console** says it at the top; **`upsmon --notices`**,
    **`--notice-done ID`**, **`--notices-check`** on the command line.
  - Where they come from: the signed package (`deploy/notices.json`, by version:
    `before` shown before the upgrade, `after` raised once it runs), root
    (`/etc/upsmon/notices.d`, `upsmon_notice` in install.sh), the daemon.
  - A notice may name a check (SELinux mode, a file, a systemd unit, a version)
    and goes by itself once it holds - nothing is ever run from it.
- **Before an upgrade**, what the new version asks is shown with the package;
  one marked `confirm` must be ticked as read before the upgrade starts from the
  pages (the server refuses it otherwise, 409) - also for "upgrade from the web"
  in one click. `upsmon --upgrade-online` and `install.sh --upgrade` show them
  and ask again; after install.sh it says what is TO BE DONE BY HAND.
- install.sh: without `semanage` the SELinux label of the pages is not kept - it
  is now said (to be done by hand) instead of passing silently.
- docs/notices.md: the format, for the versions to come. Tests in tests/notices/.

## 4.4.6 - 2026-11-06

- **The performance meter's graphs flow from the right to the left, smoothly
  and together.** The newest reading is always at the right edge, from the
  very first readings (not only once two minutes are full), and the line moves
  a step left over the time until the next reading - as long as the readings
  have lately been coming apart, so one step runs into the next without a stop.
  It is a CSS animation of each graph now: 4.4.4's SVG animation did not run on
  the live page in some browsers, and the line stood still. Every graph has the
  same clock, so they all move together. Still nothing redrawn by a timer.
- **Coming back draws the last state at once** - F5, from the dashboard, the
  next day: the numbers and the graphs as they were, and the next reading only
  brings them up to date. Kept in this browser (localStorage), the time away
  drawn as a gap; signing out takes it away.

## 4.4.5 - 2026-11-06

- **Your account -> Passkeys looks as in the other apps.** Each row has a pencil
  and a bin, icons only. The pencil turns the name into a box with the name
  selected: Enter, the pencil again or a click elsewhere keeps it, Esc puts it
  back, an emptied box keeps the old name. The "synced" tag is gone from the
  name (it is said when pointing at it). The same table shows for a full
  administrator from the row of another account.

## 4.4.4 - 2026-11-05

- **The performance meter's graphs slide smoothly.** Each graph (in the header and
  in the panel) is one SVG animation that moves the line one step to the left over
  the 3 s until the next reading - nothing is redrawn by a timer, the page only
  draws again when a reading comes. Drawn again in the middle (the panel opened)
  it goes on from where it was. Nothing moves before the two minutes are full (the
  line grows to the right), nor with "reduce motion" set in the system.
- Nothing more is read or written for it: still one request every 3 s while the
  page is open and shown, none once it is closed or hidden.

## 4.4.3 - 2026-11-05

Fixes in the performance meter:

- **Free space only from the kernel's own filesystems.** The disks panel asked
  `statvfs` of every mount but the pseudo ones, and let network shares through on
  purpose: an NFS or CIFS server that is not answering made it hang, and FUSE
  mounts (ntfs-3g, mergerfs, sshfs) answer through a program of their own. Only
  ext2/3/4, xfs, btrfs, zfs, f2fs, exfat, ntfs3, jfs, reiserfs, nilfs2 and
  bcachefs are asked now.
- **No bar at 0 %.** Bars were drawn at least 1 % wide (2 % in the pills) and a
  ring's round end drew a dot, so an idle core, disk or filesystem showed a
  sliver beside "0 %". Nothing is drawn below 0.5 % now, in every look and style.
- **The process bars are the real share** - of one core (or of the busiest past
  100 %) and of the memory in use - not of the busiest process, which gave a
  process at "0 %" a third of the bar.
- **Every core has its temperature.** The sensor's "Core N" is the physical core.
  It was matched to the logical CPU of the same number, so with hyperthreading,
  gaps in the core numbers or two packages half the rows had none. The topology
  in sysfs says which core each CPU is.
- Switched off (Settings -> About, the default) the meter reads nothing: no
  header, no requests from the pages, and the API refuses before it reads.

## 4.4.2 - 2026-11-05

- **Sign in with a passkey shows from every computer, not only from the server
  itself.** For a visitor from elsewhere the sign-in page keeps only a few words of
  what the daemon says (so it tells strangers nothing), and whether passkeys are on
  was not among them: the button was never drawn. It is kept now. (4.4.1's tests
  ran from the server itself, where nothing is taken away.)

## 4.4.1 - 2026-11-05

- **Sign in with a passkey is offered as soon as passkeys are switched on** - it was
  shown only once some account had added one, so right after switching it on the
  sign-in page had no button and it looked as if the switch had not worked.
- The button pressed with no passkey on the device (or the window closed) says what
  to do: sign in with the password once, then Your account → *Add a passkey of
  this device*.

## 4.4.0 - 2026-11-05

**Sign in with Face ID, Touch ID, Windows Hello (passkeys, WebAuthn)** - as ai has it
(`docs/ipad-and-passkeys.md`, chapter 1); **off by default**:
- Settings → Accounts → *Sign in with a passkey*: on, each account adds its own in
  **Your account → Passkeys - Face ID, Touch ID** (*Add a passkey of this device*);
  the sign-in page then offers **Sign in with a passkey** - no name, no password.
  Shown only where it can work: switched on, a passkey there, a browser that
  can (HTTPS and a name, not an address).
- The server keeps only the public half (ES256, RS256, EdDSA); a challenge is once,
  5 minutes, bound to its kind, the account and the name; the origin, the name
  (rpIdHash), user presence **and verification** (face, finger, PIN), the
  signature and the counter checked; at most 20 on an account; tries counted as
  wrong passwords are; the account must be there and on. Every addition, removal,
  sign-in and refusal is an event.
- A full administrator sees and takes away anybody's from the row of the account
  (a lost iPad); `upsmon --passkeys [NAME]`, `upsmon --passkey-forget ID|all`.
- upsmon has no second step of signing in, so a passkey is the whole sign-in
  (ai's *passkey is the second step* is not needed here).
- Tested: 30 checks of the server (`tests/passkeys/t_passkeys.py`) and the whole
  round in Chromium with a virtual authenticator (`tests/passkeys/e2e.js`, 11 of 11).

**iPad** (chapter 2 and 4):
- *Add to Home Screen*: an icon of its own (the battery, 180/192/512 px, RGB on the
  app's colour, square - iOS rounds it), `manifest.json` (standalone, any
  orientation), the dashboard and Settings in a window without Safari's bars.
- The safe areas of the screen on both sides; lists scrolled by a finger, a modal
  not passing its scroll to the page; buttons and fields a finger can hit
  (`pointer: coarse`); what a mouse opens by pointing opens with a tap and closes
  with a tap elsewhere (`hover: hover` decides: an iPad with a trackpad works as a PC).
- Looked at on an iPad Pro 11" across and upright: nothing wider than the screen.
  (The terminal and its full screen of the document are ai's own: upsmon has none.)

**The load of the server in the header (performance meter)** - from ai's
server-load package (`docs/server-load.md`); **off by default**:
- Settings → About → *The load of the server in the header*: CPU, memory, the disks,
  the network in the head of Settings, every 3 s while the page is shown; pointed at
  (or tapped): the cores, their speed and temperature, the sensors, each disk, the
  filesystems, the cards, the processes taking most. Four looks and five styles of
  the details, each account picking its own in Your account (kept with the account).
- A full administrator only; read from /proc and /sys only when a page asks, the
  details only while a panel is open; nothing in the background.
- **The graphs stay across a reload**: F5 draws what was there at once and goes on
  from it (this tab, the last two minutes; the time away drawn as a gap).
- Tested: `tests/server-load/` (off, on, details only while open, the pickers, F5).

**Fixed**: `upsmon --lockouts-clear` did nothing - the service never read what it
asked (it published the list and did not look for the ask). It does now.

## 4.3.5 - 2026-11-04

**Reading what `--set` and `--setting` change**, on the command line:
- `upsmon --get VAR` - a variable of the UPS: the value alone for one (for a
  script), `VAR = VALUE` for several (`--get A --get B`), `--json` as JSON. From
  upsd; where upsd cannot be reached from here, the values the daemon read last -
  said so on stderr, the value alone still on stdout. A variable the UPS does not
  have: exit 1, with the names that look like it.
- `upsmon --setting KEY` (no `=`) - a setting of the pages as it is now, the same
  ways; a secret as dots and its last two, as on the pages. `KEY=VALUE` changes it
  as before; both at once is refused.

## 4.3.4 - 2026-11-03

- Certificates and TLS → **Upload takes a .zip** - the one *Download → Both* gives
  (two PFX, or two PEM with their keys), or one made by hand with PEM, DER or
  PFX files in it: unpacked by the daemon in memory and taken like the files
  themselves, so a dual certificate goes out and comes back the same. At most
  two PFX in all, ten small files, none locked; a wrong PFX password is said so.

## 4.3.3 - 2026-11-03

**A dual certificate (RSA + its ECDSA twin) by hand** - Settings → Certificates and TLS:
- **Upload** takes both: PEM with the two certificates and their two keys (any
  order, all in one), or two PFX files with the same password. They are paired by
  their keys; one RSA and one ECDSA for the same names are kept as one dual
  certificate (RSA first, the ECDSA twin beside it - nginx gets both), else
  refused with why (two of one kind, other names, more than two keys). One
  certificate with one key goes exactly as before - and puts the twin of the one
  before aside.
- **Download** of a dual one asks *Which certificate*: the RSA one, the ECDSA
  twin (`-ecdsa` in the name), or **both** - a `.zip` with a file each in the
  format chosen, each with its own key (a PFX holds one key, so two PFX).
  Before, only the RSA certificate and its key came out.
- `upsmon --cert-export FORMAT --cert-which main|alt|both`.

## 4.3.2 - 2026-11-01

- **Certificates from acme looks and works exactly as in ai 1.0.60**: the state in
  the card's head (off / on - not paired yet / on - paired), the two switches in
  the card, the tiles - the address for acme, this server's id, its sealing key -
  each copied with a click; Pair with an acme shows the code large, with the
  address and until when, a click copies it; Or paste acme's key with a name for
  it; Paired with, What acme sees here, the last push. The switches and *Forget
  it* (struck through, *Keep it*) wait for **Save changes** at the bottom;
  *Put them back* throws them away. Czech words as ai's.
- The address shown for acme is `https://NAME/` (as ai's); `/settings/` works the
  same.

## 4.3.1 - 2026-11-01

- Certificates from acme: *Take certificates from acme* and *Take certificates of
  other names* are settings of the pages now - a click only marks them changed,
  and **Save changes** at the bottom (or *Put them back*) does it, as on every
  other pane. What 4.3.0 kept apart is taken over once by itself. The actions on
  the card (Pair with an acme, paste a key, Forget it, Take it back) are done
  when pressed, as before.

## 4.3.0 - 2026-11-01

**Certificates from acme (acme push, protocol 1)** - Settings → Certificates and
TLS, a new card. Your acme pairs with this server once and then puts its
certificate in and renews it (`docs/acme-push-protocol.md`):
- The four requests at `https://NAME/settings/?api=acme-push-…` (and at `/`):
  `hello`, `pair`, `inventory`, `install`. The page decides nothing: the raw body
  and the five `X-Acme-Push-*` headers go to the daemon as they came.
- Every request signed by acme (Ed25519 over the seven lines), time within
  300 s, each nonce once (kept in the database 15 minutes); the certificate's
  key sealed to this server (X25519 + HKDF-SHA256 + AES-256-GCM).
- Pairing with a code (16 characters, 15 minutes, five tries, once), or acme's
  key pasted. The acmes paired listed, each *Forget it*.
- One slot, `node:NAME`: the certificate's name, what is there now and who looks
  after it. A dual one (RSA + its ECDSA twin) is taken; the same again is
  `already`; certificates of other names only when switched on.
- The cryptography from the `cryptography` package where the Python has it,
  else in plain Python - both checked against the document's test vectors.

**Only one more way - nothing else changes** (chapter 0 of the document): off
by default; a pushed certificate is stored exactly where an upload is, through
the same code, and counts as one (own ACME leaves it alone, *Look after it*
gives it back); upload, CSR, self-signed, own ACME, export, copies and the
command line as before - tested with push off and with push on and paired
(`tests/acme-push/`). Every install is an event "by acme push, key …".

## 4.2.5 - 2026-11-01

**Passwords kept: a full administrator sees dots and their last two characters,
typing shows dots only** - checked through the whole application:
- Settings: the proxy's password, the password of the backups, the deSEC token,
  the Cloudflare token, the acme-dns key, the TSIG secret - on the pages and in
  `upsmon --settings`.
- Backups → a destination: its password, and now also **the passphrase of its
  ssh key** (kept, but not shown before) beside the key.
- Not kept anywhere, so nothing to show: the passwords of the accounts (a hash
  only), and what is asked for one moment (a certificate's export, a PFX
  uploaded, a copy's passphrase).
- Anyone else than a full administrator gets nothing of them.

**`upsmon --set VAR=VALUE` and `--exec`** (a value of the UPS, a command)
stopped at once since 3.6.7 ("'Namespace' object has no attribute 'pin'"): the
`--pin` they read was never offered. It is now (asked on the terminal when not
given).

## 4.2.4 - 2026-11-01

- **Only errors on the machine's console** (as otp 1.0.210): lines like
  `systemd-rc-local-generator: /etc/rc.d/rc.local is not marked executable,
  skipping` came in bursts over the login prompt and the upsmon console on tty1
  - systemd's generators write to the kernel's log at every daemon-reload (a dnf
  update, an upgrade), and a console log level of 7 put all of it on the screen.
  install.sh writes `/etc/sysctl.d/80-upsmon-console.conf` (`kernel.printk = 4 4
  1 7`, RHEL's own default) and applies it; the journal keeps everything
  (`journalctl -k`). A `kernel.printk` set by hand in another file is left alone;
  the same file on every run; taken away by --uninstall. rc.local is not made
  executable.

## 4.2.3 - 2026-10-31

**Settings → Proxy: a switch for each thing that may go through it** - all off
by default, and with "Go out through a proxy" off nothing goes through it
whatever they say:
- *New versions of upsmon* - Settings → Upgrades: the daily look and the
  download (GitHub).
- *System updates (dnf, apt)* - Settings → System updates: the look and the
  update, handed to root's helper.
- *Automatic certificates: the CA* - every question to Let's Encrypt (or your
  own CA): the account, the order, the certificate.
- *Automatic certificates: the DNS API* - DNS-01 through deSEC, Cloudflare or
  acme-dns.

Never through it, nothing to switch: the UPS, the plug and the sensors (on the
network), the backups (FTP, FTPS, SFTP, SCP, SMB), the time (NTP), RFC 2136
(nsupdate) - none of them speaks HTTP. *Try it* goes through the proxy whenever
it is on, to try the proxy itself.

Where the proxy was on before, its use for the updates has to be switched on
again here: the new switches start off.

## 4.2.2 - 2026-10-31

- **The proxy is for the updates only**: the new versions of upsmon (the daily
  look, the download) and the system updates (dnf, apt, when "The system updates
  through it too" is on). Nothing else goes through it, whatever is set: the
  automatic certificates (the CA, deSEC, Cloudflare, acme-dns) go straight
  again, as do the UPS, the plug, the sensors, mail and the backups - none of
  them can be stopped by a proxy that is down or wrongly set. Settings → Proxy
  says so.

## 4.2.1 - 2026-10-31

**Settings → Proxy** - a pane of its own, as OTP has it (Server, before Time):
- *Settings*: Go out through a proxy, the proxy, its user name and password
  (sealed), the names reached straight, and **the system updates through it
  too** (dnf, apt - handed to root's helper, never on a command line).
- *Try it*: an address asked the way upsmon asks the web - through the proxy as
  saved, or straight - drawn as OTP draws it: this server, the proxy, the
  address, each link green or red, and every step (looked up, connected, the
  tunnel, TLS and its certificate, the answer) with how long it took. Empty:
  where the new versions are looked for.
- `upsmon --proxy-test [URL]` on the command line (`--json` too).
- The proxy's settings are no longer in Settings → Upgrades.

## 4.2.0 - 2026-10-31

**Upgrades and maintenance, as OTP 1.0.197 has them (one server, no HA)**
(Settings → Upgrades):
- *The nodes*: this server with its version, when it was heard from, its state
  (in service / in maintenance, why, by whom, since when) and **Maintenance** /
  **Back in service**.
- **Maintenance** takes upsmon out of service the way OTP does for its node:
  the UPS, the plug and the sensors are still watched and their history kept,
  but nothing changes them - a command to the UPS, a value set on it, the plug
  switched or reset, a reset of what is recorded are refused (HTTP 503, "upsmon
  is in maintenance"); the dashboard says so at the top, `/api/status` and
  `/api/health` carry `maintenance` (health: `"state": "maintenance"`) for
  monitoring. An upgrade, a system update and a restart from these pages put it
  in maintenance and back by themselves.
- `upsmon --maintenance on --why "..." | off | status` (status exits 3 while in
  maintenance); the command-line card lists it.
- *What root said last* folded until opened, as in OTP 1.0.196.

**Automatic certificates → In your DNS**: laid out across the whole width,
every column a fixed share and the copy buttons in narrow columns of their own,
one under the other - nothing moves between a reload (F5) and Check DNS; the
last check is kept across a reload in that tab.

## 4.1.11 - 2026-10-31

- Automatic certificates → In your DNS: the copy buttons line up one under the
  other, right after the longest text of their column; the columns stay as
  wide as what they hold, with room between them.

## 4.1.10 - 2026-10-31

- Automatic certificates → In your DNS: each copy button right after its text;
  the columns as wide as what they hold, with room between them, instead of
  the first column taking all the width.

## 4.1.9 - 2026-10-31

- Automatic certificates → In your DNS: the copy buttons sit in a column of
  their own, right after the longest text and one under the other - laid out
  by the table itself, so they no longer jump at every refresh (they were
  measured and moved after drawing).
- The column "Record" there is "DNS record" ("Záznam DNS" in Czech; it read
  "Bilance", the dashboard's word).

## 4.1.8 - 2026-10-31

- Automatic certificates → The CA's own certificate (and every setting that
  holds a certificate in PEM): a large memo across the whole width instead of
  a one-line box - monospace, not wrapped, resizable; **Load a file…**
  (.pem, .crt, .cer) or a file dropped onto it; **Empty**; and under it what
  it holds: "1 certificate in PEM", not PEM, or a private key that does not
  belong there.

## 4.1.7 - 2026-10-31

- ACME: an order stopped with "the key is ec, ec384, rsa2048, rsa3072 or rsa4096" -
  the order's loop reused the name of the key's kind for the challenge's
  (dns-01 / http-01). Fixed; tested through the whole order with both challenges.
- Automatic certificates → What the last order did: the time stays one narrow
  column (+102 s no longer breaks into a line per character) and the words sit
  left beside it.

## 4.1.6 - 2026-10-31

Automatic certificates (ACME) take every key Let's Encrypt accepts
(https://letsencrypt.org/docs/integration-guide/):

- **The certificate's key:** RSA 2048, 3072, 4096 or ECDSA P-256, P-384 - and,
  the new default, **both**: two certificates for the name, RSA served by
  default and the much smaller ECDSA one to the clients that take it
  ("Both: RSA 2048 + ECDSA P-256", or "Both: RSA 4096 + ECDSA P-384").
  The second order only signs: the name is already proven. nginx gets two
  `ssl_certificate` / `ssl_certificate_key` pairs (`upsmon.pem` and
  `upsmon-ecdsa.pem`); a certificate put in another way on Certificates and
  TLS drops the ECDSA one.
- **The account's key** (new setting): ECDSA P-256 (ES256), P-384 (ES384) or
  RSA 2048, 3072, 4096 (RS256) - never a certificate's key. A change makes a
  new account at the next order.
- The keys show on the ACME card (Keys), on the certificate (Key) and beside
  the account; the order's steps say which keys were made.

## 4.1.5 - 2026-10-31

- Backups to an SMB share work: the service may now open netlink sockets (`AF_NETLINK` in `upsmon.service`), which smbclient needs to read the machine's network interfaces. Before, it stopped with "Could not determine network interfaces, you must use a interfaces config line".

## 4.1.4 - 2026-10-31

- Settings → System updates: the tag "restart after the update" (or "restart needed") sits on a line of its own under the server's name.
- Links on the pages (e.g. "back to the dashboard" on the sign-in page) are the application's blue, visited or not - no more hard-to-read purple.

## 4.1.3 - 2026-10-31

- **The newest Python** (as OTP chooses it): every install and upgrade puts
  upsmon on the newest Python the system offers beside its own - on AlmaLinux
  / RHEL 9 (whose own python3 is 3.9) python3.14, 3.13, 3.12 or 3.11, the
  first that AppStream has, installed when missing - and takes it only once
  it is shown to run upsmon. The choice is the link
  `/usr/local/lib/upsmon/python`; `upsmon.service` and the `upsmon` command
  start it. `--python PATH` or `--system-python` choose otherwise, and the
  choice is kept for later upgrades (the ones from the pages too).
- colorama installed for that Python (its own package, else pip).

## 4.1.2 - 2026-10-31

- **PHP on the stream php:8.3, at least 8.3.36** (php2shell): every install and
  upgrade now puts PHP on the AppStream stream `php:8.3` - from 8.0, 8.2 or
  any other stream: `dnf module reset php`, `dnf module enable php:8.3`,
  `dnf distro-sync 'php*'`, php-fpm restarted; on php:8.3 already, its newest
  build. It says whether 8.3.36 or later runs. `--php-stream X.Y` still
  chooses another stream (its own fixed build is then the one checked:
  8.2.35, 8.4.27, 8.5.12).

## 4.1.1 - 2026-10-31

- **PHP on the stream php:8.2, at least 8.2.35** (php2shell, CVE-2026-109618,
  CVE-2026-109619): `install.sh` - on a fresh install and on every upgrade,
  from the command line or from Settings → Upgrades - puts PHP on the
  AppStream stream `php:8.2` whatever was there before (AlmaLinux 9's own
  8.0, or another stream): `dnf module reset php`, `dnf module enable
  php:8.2`, every PHP package moved over (`dnf distro-sync 'php*'`), php-fpm
  restarted on it. Already on php:8.2, it is brought up to the newest build.
  It then says whether 8.2.35 or later runs, and how to get it where the
  mirror has not got it yet. `--php-stream X.Y` chooses another stream,
  `--remi` Remi's 8.4, `--no-php-update` leaves PHP alone.

## 4.1.0 - 2026-10-31

More of OTP's Settings, the same pages and the same functions, for upsmon:

- **Time** - the clock as chrony keeps it: how far off, its sources, stratum,
  the time servers set from here (or `/etc/chrony.conf` left as it is), the
  time zone, a step to the right time now. `install.sh` installs and starts
  chrony, as OTP's does.
- **The database** - both SQLite files (`history.db`, `upsmon.db`): how big,
  every table counted, the disk under them and how fast they grow; a copy of
  both a day (`backup_daily`, `backup_at`, `backup_keep`), a copy now,
  download one (with the key, locked with a passphrase, or without), put one
  back (shown first; a copy of what it replaces made first; the service
  restarts on it), read them through, give the disk back, forget old
  records, erase what was collected (the history of the UPS, its events,
  power failures, tests, the plug, the sensors, the events of the pages).
- **Backups** - everything (both databases, the key, config.json, RESTORE.md)
  to a folder, FTP, FTPS, SFTP, SCP or SMB, locked with a password
  (AES-256), on a schedule, the oldest taken away, tried (opened, every file
  checked, both databases read through), and put back.
- **System updates** - dnf looks every day, the updates put in from here or
  on a schedule (all, or security only), a restart offered or made when one
  is needed.
- **Restart and power off** - this server, now or on a schedule.
- **Certificates and TLS → Download** - a window to choose the format: PEM
  with the chain, the certificate alone (PEM or DER), PFX / PKCS#12 (AES-256,
  or 3DES for older Windows and Java), PEM with the private key or the key
  alone - with a password, typed unseen. Every export with the key goes into
  Events. On the command line: `upsmon --cert-export pfx --out FILE`.
- **PHP and php2shell** (CVE-2026-109618, CVE-2026-109619): `install.sh`
  does what OTP's does - PHP put on the AppStream stream 8.3 where there is
  none, an installed one brought up to the newest build, checked by its
  version and by its changelog (a backport keeps the old number), Remi's 8.4
  offered (`--remi`) where AppStream has no fixed build, and the guard always
  (`99-php2shell.ini`, a pool that takes no body apart, nginx refusing
  multipart). `--php-stream X.Y`, `--no-php-update`.
- Secrets saved on the pages (the password of the backups, of the proxy, the
  DNS keys) show as dots and their last two characters; typed, dots only.
- **The command line in OTP's colours** - `--help` in two columns, in colour
  (colorama, installed where it can be), every line of output coloured as
  OTP colours it; new: `--backup`, `--copies`, `--restore`,
  `--restore-bundle`, `--rbackup-now`, `--rbackup-status`, `--db-check`,
  `--time [sync]`, `--updates status|check|start|cancel`, `--restart-server`,
  `--poweroff-server`, `--restarts`, `--lockouts`, `--lockouts-clear`,
  `--cert-export`.
- **The console** - new menus: *The database and backups* and
  *Certificates, updates, restarts, the time*.
- `upsmon.service`: `ProtectSystem=full` (was strict), so a backup can go to
  a folder mounted anywhere; more room for keys and copies.

## 4.0.0 - 2026-10-31

The standalone upsmon rebuilt on the engine and the pages of OTP (1.0.187).
The dashboard does exactly what it did - the UPS, the smart plug, the sensors,
the history, the tests, the control behind the PIN - and still asks nobody to
sign in. Beside it, **Settings** (`/settings/`), which nobody reaches without
an account, with OTP's own pages, the same UI and the same functions:

- **Accounts** - full admin and read only, passwords (PBKDF2-SHA256), who is
  signed in now and ending a sign-in, lockouts after wrong passwords (per
  address and per name) and clearing them, the columns of every table laid
  out per person (Edit the columns), one's own settings exported and imported.
- **Certificates and TLS** - a certificate uploaded (PEM in any order, or
  PFX / PKCS#12 with its password), a request (CSR) made here and the answer
  uploaded, a self-signed one; the protocols and ciphers (standard,
  intermediate, modern, custom), DH parameters, HSTS. Put in nginx by root
  (`upsmon_web.py`, started by `upsmon-web.path`), nginx asked before it is
  reloaded and put back as it was when it says no.
- **Automatic certificates** - ACME (Let's Encrypt, its staging or another
  CA), HTTP-01 on port 80 or DNS-01 (by hand, RFC 2136, Cloudflare, acme-dns,
  deSEC), renewed by themselves; Try port 80, Check DNS, the certificate from
  before put back with a click.
- **Upgrades** - a signed package sent from the pages, or found on the web
  (`upgrade_url`, by default this repository's `release/` folder) once a day
  and put in with one click; checked (Ed25519 signature, every file) by the
  daemon and again by root (`upsmon_upgrade.py`, started by
  `upsmon-upgrade.path`), which runs its `install.sh --upgrade --yes`. Going
  back to an older version, only a safe one, when switched on.
- **About** - the version and what it runs on (Python, OpenSSL, SQLite,
  nginx, PHP and its extensions), the language of the pages, the debug log,
  the console at login.
- **Events** - every sign-in, account, setting, certificate and upgrade.

Also from OTP:

- **Czech and English** for every page, the dashboard included - CS / EN in
  the header of the dashboard and on the sign-in, each person's own language
  in their account, `ui_lang` for everybody else.
- **The console** - `upsmon --console`, the whole of upsmon by its menus on
  the terminal (the UPS, checks, the live log, accounts, settings,
  certificates, upgrades, the service), and at root's login
  (`upsmon --console-at-login on|off`).
- **The command line of Settings** - `--users`, `--add-user`, `--passwd`,
  `--set-role`, `--del-user`, `--disable-user`, `--enable-user`,
  `--settings`, `--setting KEY=VALUE`, `--audit`, `--cert`,
  `--cert-selfsigned`, `--acme`, `--acme-order`, `--upgrade-check`,
  `--upgrade-online`, `--upgrade-status`, `--upgrade-follow`,
  `--upgrade-cancel`, `--downgrade-check`, `--downgrade`, `--maintenance`.

What changed underneath:

- `upsmon_admin.py` beside `upsmon.py`: the daemon starts it in threads of its
  own; whatever happens to it, the UPS is watched. Its own SQLite database,
  `/var/lib/upsmon/upsmon.db` (the history stays in `history.db`), its own API
  on 127.0.0.1:9849 with its own token (`/run/upsmon/admin-token`).
- The pages run in a php-fpm pool of their own (`upsmon`, as `upsmon-www`),
  and speak to the daemon over a socket (no `allow_url_fopen`).
- nginx: `/etc/nginx/conf.d/upsmon.conf` in OTP's shape - the dashboard at
  `/`, Settings at `/settings/`, ACME on port 80; the certificate in
  `/etc/nginx/certs/upsmon.pem` / `upsmon.key`.
- `upsmon --diag` used a function it did not have (`ago`) when a sensor had
  pushed something; it has it now.

Upgrading from 3.x (`sudo ./install.sh --upgrade`): the configuration, the
history and the certificate are kept - `server.pem` / `server.key` /
`server.ca` are carried over to the new names, and the nginx file is written
afresh with the host name and the allow list of the old one (which is kept as
`/etc/nginx/upsmon.conf.before-4.0`). The first account of Settings is made
and its password printed. From then on, new versions come by Settings →
Upgrades.
